function Add(){
    alert ("Do you want to add tickets?")

}
export default Add;