function Edit(){
    alert ("do you want to edit the records")
}
export default Edit;