function remove() {
    alert("Do you want to delete the record?");
}
function edit() {
    alert("Do you want to edit the ticket details?");
}
var es = "Hello world";
console.log(es)