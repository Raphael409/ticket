function Record(){
    alert ("tickets list")
}
export default Record;